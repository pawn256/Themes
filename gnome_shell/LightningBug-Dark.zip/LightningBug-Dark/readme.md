# Credits

This themes base on <b>Mint-Y-Theme</b></br>
Links :  https://github.com/linuxmint/mint-y-theme </br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation

Needed : GTK+ 3.22</br>
Have been test on : Debian Stretch (9.5), Ubuntu 18.04.1 LTS, Linux Mint 19.1</br>
Install themes : For a better result, Extract Archive File On Directory<i> /usr/share/themes (as root),</i> </br>
If you install theme on local system, <i>/.themes or /.local/share/themes</i> may be GTK2 Theme not working properly.</br>
Download themes : https://www.opendesktop.org/p/1238824/</br>

## Change themes

"This is the theme of gtk+ 3 and gk+ 2. You can use it on Linux distributions in every desktop environment that supports it"</br>
Debian, Ubuntu (Gnome Desktop) : Use Tweak Tool to change the themes, Gnome Tweak > Appeareance > Themes</br>
Linux Mint (Cinnamon): Menu > Settings > Themes > Themes > Controls</br>


